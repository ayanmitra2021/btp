import {Body, Controller, Get, Param, Patch, Post, Query, Delete} from "@nestjs/common";
import {CommandBus, QueryBus} from "@nestjs/cqrs";
import {ApiBadRequestResponse, ApiCreatedResponse, ApiForbiddenResponse, ApiOperation, ApiTags} from "@nestjs/swagger";
import {RequiredPermissions} from "src/auth/required-permission.decorator";
import {QueryBusinessPartner} from "src/modules/business-partner.module/queries/query-business-partner";
import {BusinessPartnerResponseDto} from "src/modules/business-partner.module/dtos/busines-partner-response.dto";
import {CreateNorthWindCategoryCommand} from "src/modules/business-partner.module/commands/create-northwind-category.command";
import {Categories} from "src/entities/odata/north-wind-service";
import {CategoryResponseDto} from "src/modules/business-partner.module/dtos/category-reponse.dto";
import { FindCategory } from "src/modules/business-partner.module/queries/find-category";

@ApiTags("BusinessPartner")
@Controller("business-partner")
export class BusinessPartnerController {
    constructor(private readonly commandBus: CommandBus, private readonly queryBus: QueryBus) {}

    @ApiOperation({summary: "List of business partners from SAP"})
    @ApiCreatedResponse({
        description: "The list of business partners from SAP has been successfully retrieved.",
        type: BusinessPartnerResponseDto,
        isArray: true,
    })
    @ApiForbiddenResponse({description: "Forbidden."})
    @ApiBadRequestResponse({description: "Bad Request."})
    @RequiredPermissions("Customer.Get")
    @Get()
    async queryBusinessPartners(@Query() query: QueryBusinessPartner): Promise<BusinessPartnerResponseDto[]> {
        return await this.queryBus.execute(query);
    }

    @ApiOperation({summary: "Create a new category"})
    @ApiCreatedResponse({
        description: "The category has been successfully created.",
        type: CategoryResponseDto,
    })
    @ApiForbiddenResponse({description: "Forbidden."})
    @ApiBadRequestResponse({description: "Bad Request."})
    @RequiredPermissions("Customer.Create")
    @Post("/category")
    async createBusinesPartnerAddress(@Body() command: CreateNorthWindCategoryCommand): Promise<CategoryResponseDto> {
        return await this.commandBus.execute(command);
    }

    @ApiOperation({summary: "Find category"})
    @ApiCreatedResponse({
        description: "The category has been successfully retrieved.",
        type: CategoryResponseDto,
        isArray: false,
    })
    @ApiForbiddenResponse({description: "Forbidden."})
    @ApiBadRequestResponse({description: "Bad Request."})
    @RequiredPermissions('Customer.Find')
    @Get('/category/:id')
    async findCategory(@Param() id: number): Promise<CategoryResponseDto> {
        console.log('Id to find ', id);
        const parameter : FindCategory= new FindCategory();
        parameter.id=id;
        return await this.queryBus.execute(parameter);
    }

}
