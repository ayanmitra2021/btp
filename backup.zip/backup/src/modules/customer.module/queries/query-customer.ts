import {UseFilters, NotFoundException, Inject, CACHE_MANAGER, Injectable} from "@nestjs/common";
import {IInferredQueryHandler, IQueryHandler, QueryBus, QueryHandler} from "@nestjs/cqrs";
import {ApiProperty} from "@nestjs/swagger";
import {Query} from "src/extensions/type-safe-cqrs/query";
import {Cache} from "cache-manager";
import {Customer} from "src/entities/customer.entity";
import {InjectRepository} from "@nestjs/typeorm";
import {FindOptionsWhere, FindOptionsSelect, FindOneOptions, Repository} from "typeorm";
import {any} from "joi";
import {IsOptional} from "class-validator";
import {ExpressQuery} from "@tool-kid/express-query-adapter/src/express-query";
import {getQueryAdapter} from "@tool-kid/express-query-adapter";
import {Transform} from "class-transformer";
import {trim} from "src/utilities/helper.utilities";

export class QueryCustomer extends Query<Customer[]> {
    @ApiProperty()
    @IsOptional()
    @Transform(({value}) => trim(value))
    public query: ExpressQuery;
}

@QueryHandler(QueryCustomer)
export class HandleQueryCustomer implements IInferredQueryHandler<QueryCustomer> {
    constructor(@InjectRepository(Customer) private customerRepo: Repository<Customer>) {}

    async execute(customerQuery: QueryCustomer): Promise<Customer[]> {
        const builder = await getQueryAdapter({adapter: "typeorm"});
        const findOption = builder.build(customerQuery.query);
        return await this.customerRepo.find(findOption);
    }
}
